package newCodes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import codes.*;


public class RestaurentClient {
    private SocketWrapper socketWrapper;
    private List<FoodCount> orders;

    public RestaurentClient(String s, int port) {
        try {
            this.socketWrapper = new SocketWrapper(s, port);
            orders = new ArrayList<>();
            Scanner input = new Scanner(System.in);
            String username, password;
            System.out.print("Enter Username: ");
            username = input.nextLine();
            System.out.print("Enter Password: ");
            password = input.nextLine();
            socketWrapper.write("RestaurantClient");
            socketWrapper.write(username);
            socketWrapper.write(password);
            String comm = (String) socketWrapper.read();
            while (true) {
                if (comm.equalsIgnoreCase("No"))
                    break;
                Food order = (Food) socketWrapper.read();
                FoodCount stat = isPresent(order);
                stat.getFd().showDetails();
                System.out.println("Count->"+stat.getcnt());
                orders.add(stat);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public FoodCount isPresent(Food f) {
        for (FoodCount temp : orders) {
            Food current = temp.getFd();
            if (f.getName().equals(current.getName()) && f.getRestaurantId() == current.getRestaurantId()
                    && f.getCategory().equals(current.getCategory())) {
                temp.rise();
                return temp;
            }
        }
        return new FoodCount(f);
    }

    public static void main(String[] args) {

        new RestaurentClient("127.0.0.1", 44444);
    }
}
