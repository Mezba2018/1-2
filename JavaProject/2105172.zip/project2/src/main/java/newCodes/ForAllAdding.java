package newCodes;


import codes.FileOperations;
import codes.Food;
import codes.Restaurant;
import codes.RestaurantManagement;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class ForAllAdding implements Runnable{
    Server server;
    private Thread th;
    RestaurantManagement restaurantManagement;


    public ForAllAdding(Server server){
        this.server=server;
        this.restaurantManagement=server.manager;
        this.th=new Thread(this);
        th.start();

    }


    @Override
    public void run() {
        Scanner scanner=new Scanner(System.in);

      while(true)  {
            int choice;
            System.out.println("For Adding Food,choice 1");
            System.out.println("For Adding Restaurant,choice 2");
            System.out.print("Enter your choice:");
            choice = scanner.nextInt();
          scanner.nextLine();

            if(choice==1)
            {
                //for food add
                System.out.println("Adding a Food Item to a Restaurant's Menu");
                System.out.print("Enter Restaurant Name: ");
                String restaurantName = scanner.nextLine();
                List<Restaurant> exist = restaurantManagement.rsearchbyName(restaurantName);
                if (exist.isEmpty()) {
                    System.out.println("No such restaurant with the provided name.");
                    break;
                }
                System.out.print("Enter Food Item Name: ");
                String foodName = scanner.nextLine();

                System.out.print("Enter Food Item Category: ");
                String foodCategory = scanner.nextLine();

                System.out.print("Enter Food Item Price: ");
                double foodPrice = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                // Create a new Food object and add it to the foodarray list
                Food newFoodItem = new Food(exist.get(0).getId(), foodCategory, foodName, foodPrice);
                boolean x = restaurantManagement.addFood(newFoodItem);
                if (x) {
                    System.out.println("New food added successfully");
                } else {
                    System.out.println("already exists the provided food.");

                }
                try {
                    FileOperations.writeMenu("C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\menu.txt", restaurantManagement.getMenu());
                    //FileOperations.writeRestaurants("C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\restaurant.txt", restaurantManagement.getRestaurant());

                } catch (Exception e) {

                }

            }


            else if(choice==2)
            {
             //for restaurant add
                // Handle Add Restaurant
                boolean go=true;
                System.out.println("Adding a New Restaurant");
                System.out.print("Enter Restaurant Name: ");
                String name = scanner.nextLine();
                List<Restaurant> exists = restaurantManagement.rsearchbyName(name);
                if (!exists.isEmpty()) {
                    System.out.println("Already exists such restaurant with the provided name.");
                    go=false;

                }

               if(go) { // boolean chk=true;

                    // System.out.print("Enter Restaurant ID: ");
                    int id = restaurantManagement.getRestaurantCount() + 1;


                    System.out.print("Enter Restaurant Score: ");
                    double score = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter Restaurant Price: ");
                    String price = scanner.nextLine();

                    System.out.print("Enter Restaurant Zip Code: ");
                    String zipcode = scanner.nextLine();

                    System.out.print("Enter Number of Categories: ");
                    int numCategories = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    String[] categories = new String[3];
                    for (int i = 0; i < numCategories; i++) {
                        System.out.print("Enter Category " + (i + 1) + ": ");
                        categories[i] = scanner.nextLine();
                    }
                    for (int i = numCategories; i < categories.length; i++) {
                        categories[i] = "-1";
                    }
                   System.out.print("Enter Restaurant Password: ");
                   String password = scanner.nextLine();

                    //  System.out.println(categories.length);

                    Restaurant newRestaurant = new Restaurant(id, name, score, price, zipcode, categories);
                    restaurantManagement.addRestaurant(newRestaurant);
                    System.out.println("New restaurant added successfully");
                   // Create a HashMap to store username-password pairs
                   HashMap<String, String> passwords = new HashMap<>();
                   passwords.put(name, password);

// Add more username-password pairs as needed

                   try {
                       // Call the writePassword method to write passwords to a file
                       FileOperations.writePassword("C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\pass.txt", passwords);
                      // System.out.println("Passwords have been written to pass.txt");
                   } catch (IOException e) {
                       System.err.println("Error writing passwords to file: " + e.getMessage());
                   }


                   try {
                        // FileOperations.writeMenu("C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\menu.txt", restaurantManagement.getMenu());
                        FileOperations.writeRestaurants("C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\restaurant.txt", restaurantManagement.getRestaurant());

                    } catch (Exception e) {

                    }
                }


            }


            else
            {
                System.out.println("Give proper choice");
            }


        }


    }
}
