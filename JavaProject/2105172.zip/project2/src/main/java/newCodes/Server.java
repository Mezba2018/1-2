package newCodes;
import codes.*;




import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;

public class Server {

    private ServerSocket serverSocket;
    private HashMap<Integer,SocketWrapper> restaurentmap = new HashMap<>();
    private HashMap<String,String> password;

   private List<Restaurant> newRes;
   private List<Food> newFood;
  public  RestaurantManagement manager;
    public Server() throws Exception {
        try {
            this.newRes = FileOperations.cRestaurant();
            this.newFood = FileOperations.cFood();
            this.password = FileOperations.password();
            manager = new RestaurantManagement(newRes, newFood);
            this.serverSocket = new ServerSocket(44444);
            new ForAllAdding(this);
        } catch (IOException e) {
            e.printStackTrace(); // Print the exception stack trace for debugging
            // Handle the exception appropriately (e.g., show an error message and exit gracefully)
            System.err.println("Error while reading files: " + e.getMessage());
            // Add additional error handling logic here
        }


//new ThreadServer(serverSocket,newRes);
        while (true) {
           // System.out.println("server is waiting");
            Socket clientSocket = serverSocket.accept();
            //System.out.println("client connected");
            serve(clientSocket);

        }

    }
    public void serve(Socket clientSocket) throws Exception{
        SocketWrapper socketWrapper = new SocketWrapper(clientSocket);
        String clientType = (String) socketWrapper.read();

        if(clientType.equals("RES")){

            String rName=(String)socketWrapper.read();
            String rPass=(String) socketWrapper.read();
          //  System.out.println("rpass="+rPass+"already saved="+password.get(rName)+"end");

            if(rPass.equals(password.get(rName))){
                for(Restaurant res:newRes){
                    if(res.getName().equalsIgnoreCase(rName) ){
                       // socketWrapper.write(res);
                        restaurentmap.put(res.getId(),socketWrapper);
//                        socketWrapper.write("Yes");
                        break;
                    }
                }
            }
           else {
//                socketWrapper.write("No");
               // System.out.println("Wrong entity");
            }
//            String userId = (String) socketWrapper.read();
//            String temp = (String) socketWrapper.read();
//            String pass = temp.trim();
//            String comp = password.get(userId);
//            System.out.println("pass: " + pass+"comp: "+comp+"userId: "+userId);
//            if (pass.equals(comp.trim())) {
//                restaurentmap.put(userId, socketWrapper);
//                socketWrapper.write("Yes");
//            } else {
//                socketWrapper.write("No");
//            }


        }
        else if(clientType.equals("USER")){
          //  socketWrapper.write("hi user");
          //  System.out.println("Inside user");

            String cName=(String)socketWrapper.read();
           // System.out.println(cName);
            RestaurantManagement restaurantManagement=new RestaurantManagement(newRes,newFood);
            socketWrapper.write(restaurantManagement);
            //System.out.println("outside");
            new ThreadClient(socketWrapper,restaurentmap);
           // System.out.println("here");

        }
    }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}

