package newCodes;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import codes.*;



public class ThreadClient implements Runnable{
    private SocketWrapper socketWrapper;
    private  HashMap<Integer, SocketWrapper> rmap;
    Thread thr;
    public ThreadClient(SocketWrapper sw, HashMap<Integer, SocketWrapper> rMap) {
       this.rmap = rMap;
       this.socketWrapper = sw;
        System.out.println("Start");
       thr = new Thread(this);
       thr.start();

    }

    void redirectOrder() throws IOException, ClassNotFoundException {

    }


    @Override
    public void run() {
        while(true){
            try {
               Food f = (Food) socketWrapper.read();
                System.out.println("Incoming");
                SocketWrapper rSocket = rmap.get(f.getRestaurantId());
                if(rSocket != null) {
                    rSocket.write(f);
                    System.out.println("Writing");
                }

            } catch (Exception e) {}

        }
    }
}
