package newCodes;

import codes.*;

import java.net.ServerSocket;
import java.util.List;

public class ThreadServer implements Runnable  {
    private List<Restaurant> restaurants;
    private ServerSocket serverSocket;
    private Thread th;
    public ThreadServer(ServerSocket serverSocket, List<Restaurant> res)
    {
        this.serverSocket=serverSocket;
        this.restaurants=res;
        this.th=new Thread(this);
        th.start();

    }
    public void run(){
        while (true){
            int id=restaurants.size()+1;
            String name="X";
            double score=1000;
            String price="Z";
            String zip="W";

            //
            int numCategories=3;
            String[] categories = new String[3];
            for (int i = 0; i < numCategories; i++) {

                categories[i] = "bal";
            }
            for (int i = numCategories; i < categories.length; i++) {
                categories[i] = "-1";
            }
           //
            Restaurant tem=new Restaurant(id,name,score,price,zip,categories);
            restaurants.add(tem);


        }
    }
}
