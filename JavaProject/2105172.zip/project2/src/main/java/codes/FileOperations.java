package codes;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileOperations {

    private static String INPUT_FILE_NAME;
    private static String OUTPUT_FILE_NAME;

    public static List<Restaurant> cRestaurant()
            throws Exception {
        INPUT_FILE_NAME = "C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\restaurant.txt";
        List<Restaurant> restaurants = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        while (true) {
            String line = br.readLine();
            if (line == null)
                break;
            // System.out.println(line);
            String[] array = line.split(",", -1);
            int id = Integer.parseInt(array[0]);
            String name = array[1];
            double score = Double.parseDouble(array[2]);
            String price = array[3];
            String zipcode = array[4];
            String[] category = new String[3];
            if (array.length == 7)
            {
                category[0] = array[5] ;
                category[1] =  "-1" ;
                 category[2] =  "-1" ;
            }
            else if (array.length == 8)
            {
                if (array[7].equals(""))
                {
                      category[0] = array[5] ;
                category[1] =  array[6] ;
                 category[2] =  "-1" ;

                }
                else
                {
                      category[0] = array[5] ;
                category[1] = array[6] ;
                 category[2] = array[7] ;

                }
            }
            // for (int i = 5; i < array.length; i++) {
            //     if(array[i].equals("")){
            //          category[i - 5] = "-1";
            //          if(i==7){
            //              category[i +1- 5] = "-1";
            //              break;
            //          }

            //     }
            //     category[i - 5] = array[i];
            // }
            try {
                // Code that may throw an exception
                // ...
                      Restaurant restaurant = new Restaurant(id, name, score, price, zipcode, category);
            restaurants.add(restaurant);
            } catch (Exception e1) {
                // Handle the exception of type ExceptionType1
                // ...
            }
      

            // for (int i = 0; i < array.length; i++) {
            // System.out.println(array[i]);
            // }
        }
        br.close();

        // String text = "Hello World";
        // BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        // bw.write(text);
        // bw.write(System.lineSeparator());
        // bw.close();
        return restaurants;
    }

    public static List<Food> cFood()
            throws Exception {
        INPUT_FILE_NAME = "C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\menu.txt";
        List<Food> foods = new ArrayList<>();
        BufferedReader br2 = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        while (true) {
            String line = br2.readLine();
            if (line == null)
                break;
            // System.out.println(line);
            String[] array = line.split(",", -1);
            int restaurantid = Integer.parseInt(array[0]);
            String category = array[1];
            String name = array[2];
            double price = Double.parseDouble(array[3]);

            Food food = new Food(restaurantid, category, name, price);
            foods.add(food);

            // for (int i = 0; i < array.length; i++) {
            // System.out.println(array[i]);
            // }
        }
        br2.close();

        // String text = "Hello World";
        // BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        // bw.write(text);
        // bw.write(System.lineSeparator());
        // bw.close();
        return foods;
    }

    /////////

    public static void writeRestaurants(String outputFile, List<Restaurant> restaurants) throws Exception {
        int count = 0, countFoodItem = restaurants.size();
        OUTPUT_FILE_NAME = outputFile;
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        for (Restaurant tempRestaurant : restaurants) {
            String id = Integer.toString(tempRestaurant.getId());
            String name = tempRestaurant.getName();
            String score = Double.toString(tempRestaurant.getScore());
            String price = tempRestaurant.getPrice();
            String zipCode = tempRestaurant.getZipcode();
            String[] categories = tempRestaurant.getCategory();
            String line = id + "," + name + "," + score + "," + price + "," + zipCode;
            for (String tempCategory : categories)
                line += "," + tempCategory;
            if (categories.length != 3)
                line += ",";
            bw.write(line);
            count++;
            if (count != countFoodItem) {
                bw.write(System.lineSeparator());
            }
        }
        bw.close();

    }

    public static void writeMenu(String outputFile, List<Food> menu) throws Exception {
        int count = 0, countRestaurant = menu.size();
        OUTPUT_FILE_NAME = outputFile;
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        for (Food tempFood : menu) {
            String id = Integer.toString(tempFood.getRestaurantId());
            String category = tempFood.getCategory();
            String name = tempFood.getName();
            String price = Double.toString(tempFood.getPrice());
            String line = id + "," + category + "," + name + "," + price;
            bw.write(line);
            count++;
            if (count != countRestaurant) {
                bw.newLine();
            }
        }
        bw.close();
    }

//    public static HashMap<String,String> password()
//            throws Exception {
//        INPUT_FILE_NAME = "C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\pass.txt";
//        HashMap<String,String> pas = new HashMap<>();
//        BufferedReader brx = new BufferedReader(new FileReader(INPUT_FILE_NAME));
//        while (true) {
//            String line = brx.readLine();
//            if (line == null)
//                break;
//            // System.out.println(line);
//            String[] array = line.split(",", -1);
//            String resname = (String)array[0];
//            String ID = (String)array[1];
//
//          pas.put(resname,ID);
//
//
//
//            // for (int i = 0; i < array.length; i++) {
//            // System.out.println(array[i]);
//            // }
//        }
//        brx.close();
//
//        // String text = "Hello World";
//        // BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
//        // bw.write(text);
//        // bw.write(System.lineSeparator());
//        // bw.close();
//        return pas;
//    }
    public static HashMap<String, String> password() throws IOException {
        String inputFile =  "C:\\Users\\Dell\\IdeaProjects\\project2\\src\\main\\java\\codes\\pass.txt";
        HashMap<String, String> passwords = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",", -1);
                passwords.put(data[0], data[1]);
            }
        }

        return passwords;
    }
    public static void writePassword(String outputFile, HashMap<String, String> newPasswords) throws IOException {
        // Read the existing passwords
        HashMap<String, String> existingPasswords = password();

        // Combine existing passwords with new passwords
        existingPasswords.putAll(newPasswords);

        // Write the combined passwords back to the file
        BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
        for (Map.Entry<String, String> entry : existingPasswords.entrySet()) {
            String username = entry.getKey();
            String password = entry.getValue();
            String line = username + "," + password;
            bw.write(line);
            bw.newLine();
        }
        bw.close();
    }

    ////////
}