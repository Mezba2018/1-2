package codes;

import java.io.Serializable;

public class FoodCount implements Serializable {
    private Food f;
   private int cnt;
    public FoodCount(Food f){
        this.f=f;
        this.cnt=1;
    }
    public void rise(){++cnt;}
    public int getcnt(){return this.cnt;}
    public Food getFd(){return f;}

}
