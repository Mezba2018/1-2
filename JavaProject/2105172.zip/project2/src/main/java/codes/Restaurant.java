package codes;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
public class Restaurant implements Serializable
{

    int id;
    String name;
    double score;
    String price;
    String zipcode;
    String[] category;
    List<String> showCategory;
    String cat="";
 //   List<String> list;

 List<Food> array = null;
  List<Food> recieve = null;

    
    
    // constructors

    // public Restaurant(int id, String name, double score, String price, String zipcode, String[] category) {
    //     this.id = id;
    //     this.name = name;
    //     this.score = score;
    //     this.price = price;
    //     this.zipcode = zipcode;
    //     this.category = category;
    // }
    public Restaurant(int id, String name, double score, String price, String zipcode, String[] category)
    {
        this.id = id;
        this.name = name;
        this.score = score;
        this.price = price;
        this.zipcode = zipcode;

        // Initialize showCategory as an empty ArrayList
        this.showCategory = new ArrayList<>();

        int i = 0;
        for (i = 0; i < 3; i++) {
            if (category[i].equals("-1")) break;
        }

        this.category = new String[i];
        for (int j = 0; j < i; j++) {
            this.category[j] = category[j];
            this.showCategory.add(category[j]);
            if(j == 0)
                cat+=category[j];
            else cat+=", "+category[j];

        }


        try {
            this.recieve = FileOperations.cFood();
        } catch (Exception e) {
            e.printStackTrace();
        }

        this.array = new ArrayList<>();
        for (Food fud : recieve) {
            if (fud.getRestaurantId() == this.id) {
                this.array.add(fud);
            }
        }
    }


    // getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }

    public String getPrice() {
        return price;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String[] getCategory() {
        return category;
    }
    public int getcount(){
        return array.size();
    }
    public String getCat() {
        return cat;
    }
public Restaurant getRes(){
        return this;
}
    // show

    public void showDetails() {
        int count = 0;
        System.out.println("Restaurant ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Score: " + score);
        System.out.println("Price: " + price);
        System.out.println("Zip Code: " + zipcode);

        System.out.print("Categories: ");
        for (String cat : category) {

            System.out.print(cat);
            if (count < category.length) {
                System.out.print(",");
            } else {
                System.out.print(".");
            }
            count++;
        }
        System.out.println();
        System.out.println();
        System.out.println();
    }

    public void fsearchByName(String fname, List<Food> matchingfoods)
    {
          for (Food fud : array) {
            if (fud.getName().toLowerCase().contains(fname.toLowerCase())) {
                matchingfoods.add(fud);
            }
         }

    }
    public void fsearchByCategory(String fname, List<Food> matchingfoods)
    {
           for (Food fud : array) {
            if (fud.getCategory().toLowerCase().contains(fname.toLowerCase())) {
                matchingfoods.add(fud);
            }
        }

    }
     public void fsearchByPrice(double up,double down, List<Food> matchingfoods)
    {
        for (Food fud : array) {
            if (fud.getPrice() >= down && fud.getPrice() <= up) {
                matchingfoods.add(fud);
            }
        }

    }
      public void fcostliest(List<Food> matchingfoods)
    {
        double maxPrice = 0.0;
        for(Food fud:array){
            if(fud.getPrice()>maxPrice){
                maxPrice=fud.getPrice();
            }
        }
          for(Food fud:array){
            if(fud.getPrice()==maxPrice){
              matchingfoods.add(fud);
            }
        }

    }
    public int ftotalfood(){
        return getcount();
    }
    public boolean exist(Food f){
       for(Food fd:array){
        if (f.getName().equalsIgnoreCase(fd.getName()) && f.getCategory().equalsIgnoreCase(fd.getCategory())) {

                return false;

       }
    }
    this.array.add(f);
return true;
    }
    public List<String> getList(){
        return this.showCategory;
    }

//    public static void main(String[] args) {
//        String []st={"a","b","c"};
//        Restaurant rs=new Restaurant(100,"100",100.0,"100","100",st);
//        List<String> xm=rs.getList();
//        for(String s:xm){
//            System.out.println(s);
//        }
//        System.out.println(rs.cat);
//    }
}
