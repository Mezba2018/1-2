module com.example.project2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.project2 to javafx.fxml;
    opens codes to javafx.base;
    exports com.example.project2;
}