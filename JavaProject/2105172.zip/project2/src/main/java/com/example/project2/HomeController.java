package com.example.project2;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController {

    @FXML
    private Button Restaurant_Management;
    @FXML
    public void customerLogin(ActionEvent event) {
        try {
            // Load the FXML file for the owner scene
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("RestaurantManager.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Login");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();}
    }
    @FXML
    public void userLogin(ActionEvent event) {
        try {
            // Load the FXML file for the owner scene
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("userlogin.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("User-Login");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();}
    }



}
