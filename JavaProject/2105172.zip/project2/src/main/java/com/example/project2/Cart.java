package com.example.project2;
/*
import codes.Food;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Cart {
    @FXML
    private TableColumn<Food, Integer> NoOrder;

    @FXML
    private TableColumn<Food, Integer> idC;

    @FXML
    private TableColumn<Food, String> nameC;

    @FXML
    private TableView<Food> tableC;

    private List<Food> orders = new ArrayList<>();

    public void showTable(List<Food> fud) {
        tableC.getColumns().clear();
        idC.setCellValueFactory(new PropertyValueFactory<>("restaurantId"));
        nameC.setCellValueFactory(new PropertyValueFactory<>("name"));
        NoOrder.setCellValueFactory(new PropertyValueFactory<>("count"));

        tableC.getColumns().addAll(idC, nameC, NoOrder);
        ObservableList<Food> data = FXCollections.observableArrayList(fud);
        tableC.setItems(data);
    }

    public void addFood(ActionEvent actionEvent) {
        try {
            // Load the FXML file for adding food
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AddingFood.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Adding Food");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void takeOrders(Food order) {
        for (Food or : orders) {
            if (order.getRestaurantId() == or.getRestaurantId()) {
                or.rise();
            }
        }

        orders.add(order);
    }
}



/
*/



        import codes.*;
        import javafx.collections.FXCollections;
        import javafx.collections.ObservableList;
        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.scene.Scene;
        import javafx.scene.control.Label;
        import javafx.scene.control.TableColumn;
        import javafx.scene.control.TableView;
        import javafx.scene.control.cell.PropertyValueFactory;
        import javafx.stage.Stage;

        import java.io.IOException;
        import java.util.ArrayList;
        import java.util.List;

public class Cart {
    @FXML
    private Label textFile;
    @FXML
    private TableColumn<Food, Integer> NoOrder;

    @FXML
    private TableColumn<Food, Integer> idC;

    @FXML
    private TableColumn<Food, String> nameC;

    @FXML
    private TableView<Food> tableC;
    public void showTable(List<Food> fud){
        tableC.getColumns().clear();
        idC.setCellValueFactory(new PropertyValueFactory<>("restaurantId"));
        nameC.setCellValueFactory(new PropertyValueFactory<>("name"));
        NoOrder.setCellValueFactory(new PropertyValueFactory<>("count"));




        tableC.getColumns().addAll(idC, nameC,NoOrder);
        ObservableList<Food> data = FXCollections.observableArrayList(fud);
        tableC.setItems(data);
    }

    private List<Food> orders = new ArrayList<>();


    public void takeOrders(Food order){
        boolean check = true;
        for(Food or:orders){
            if(order.getName().equals(or.getName()) && order.getCategory().equals(or.getCategory())){
                or.rise();
                check = false;
            }
        }
        if(check)
            orders.add(order);
        seeing();
    }

    public void seeing() {
        textFile.setVisible(true);
        tableC.setVisible(true);
        showTable(orders);
    }

//public Cart(){
//        showTable(orders);
//}

}