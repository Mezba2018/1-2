package com.example.project2;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import codes.*;
import newCodes.SocketWrapper;

import java.io.IOException;
import java.util.HashMap;

public class RestaurantManagerController {
    @FXML
    private ChoiceBox<String> choiceBox;
    @FXML
    private Button login;
    @FXML
    private TextField name;
    @FXML
    private PasswordField password;
    @FXML
    private HashMap<String,String> passwords;
    public  RestaurantManagerController() throws IOException {
        //this.passwords=FileOperations.password();
    }

    public void resReq(ActionEvent actionEvent) {
        try {

            // Load the FXML file for the owner scene
            this.passwords=FileOperations.password();
            String pass=password.getText();
            String info=name.getText();
            if(pass.equals(passwords.get(info))) {
                String address = "127.0.0.1";
                int port = 44444;
                SocketWrapper socketWrapper = new SocketWrapper(address,port);
                socketWrapper.write("RES");
                socketWrapper.write(info);
                socketWrapper.write(pass);

                    // Load the FXML file for the owner scene
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("cart.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(), 600, 400);
                    Stage stage = new Stage();
                new ThreadRestaurantOrderRead(socketWrapper, fxmlLoader.getController());

                    stage.setTitle("current Food cart");
                    stage.setScene(scene);
                    stage.show();

            }
            else{
                showAlert();
            }
        } catch (IOException e) {
            e.printStackTrace();}
    }
    void showAlert(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect entry!!!");
        alert.setHeaderText("Use proper identification!!!");
        alert.showAndWait();
    }
}
