package com.example.project2;
import codes.RestaurantManagement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import newCodes.SocketWrapper;

import java.io.IOException;

public class UserController {

    @FXML
    private Button search_Restaurant;

    @FXML
    private Button search_food;
    @FXML
     RestaurantManagement restaurantManagement;
    @FXML
    SocketWrapper socketWrapper;
    @FXML
    void searchOption(ActionEvent event) {




    }

    public void searchbyName(ActionEvent actionEvent) throws Exception {
//        if(true) {
//            // Load the FXML file for the owner scene
//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("new.fxml"));
//            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
//            Stage stage = new Stage();
//            stage.setTitle("Search");
//            stage.setScene(scene);
//            stage.show();
//        }else{
//            //showAlert();
//        }
    }
public void getter(RestaurantManagement restaurantManagement, SocketWrapper socketWrapper){
         this.restaurantManagement=restaurantManagement;
         this.socketWrapper=socketWrapper;
}
    public void search(ActionEvent actionEvent) throws Exception {
        if(true) {

            // Load the FXML file for the owner scene
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("new.fxml"));
            Parent root = fxmlLoader.load();
            NewController controller=fxmlLoader.getController();
            Scene scene = new Scene(root, 600, 400);
            controller.getterR(this.restaurantManagement,socketWrapper);
            Stage stage = new Stage();
            stage.setTitle("Search");
            stage.setScene(scene);
            stage.show();
        }else{
            //showAlert();
        }

    }

    public void Fsearch(ActionEvent actionEvent) throws Exception {
        if(true) {
            // Load the FXML file for the owner scene
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("forFoodSearch.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            ForFoodSearch controller=fxmlLoader.getController();
            controller.getterF(this.restaurantManagement,socketWrapper);
            Stage stage = new Stage();
            stage.setTitle("Search");
            stage.setScene(scene);
            stage.show();
        }else{
            //showAlert();
        }

    }


}