package com.example.project2;

import codes.Food;
import codes.Restaurant;
import newCodes.SocketWrapper;

import java.io.IOException;

public class ThreadRestaurantOrderRead implements Runnable{
    private SocketWrapper socketWrapper;
    private Cart controller;
    Thread th;
    public ThreadRestaurantOrderRead(SocketWrapper sw, Cart cart){
        this.socketWrapper = sw;
       this.controller = cart;
       th = new Thread(this);
       th.start();

    }


    @Override
    public void run() {
        while(true){
            try {
                Food f = (Food)socketWrapper.read();
                System.out.println(f.getName());
                controller.takeOrders(f);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        }
    }
}
