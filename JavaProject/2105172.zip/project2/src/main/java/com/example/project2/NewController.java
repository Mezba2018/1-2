package com.example.project2;

import codes.Restaurant;
import codes.RestaurantManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import newCodes.SocketWrapper;

import java.io.IOException;
import java.util.List;

public class NewController {

    @FXML
    private TextField category;

    @FXML
    private Label showCat;

    @FXML
    private TableColumn<Restaurant, String> categoryRc;

    @FXML
    private Button find;

    @FXML
    private TableColumn<Restaurant, Integer> idRc;
    @FXML
    private ComboBox<String> searchBy;

    @FXML
    private TextField name;

    @FXML
    private TableColumn<Restaurant, String> nameRc;

    @FXML
    private TextField price;

    @FXML
    private TableColumn<Restaurant, String> priceRc;

    @FXML
    private TextField scoreH;

    @FXML
    private TextField scoreL;

    @FXML
    private TableColumn<Restaurant, Double> scoreRc;

    @FXML
    private TextField search;

    @FXML
    private TableView<Restaurant> tableRestaurant;

    @FXML
    private TextField zip;

    @FXML
    private TableColumn<Restaurant, String> zipRc;
    @FXML
    private RestaurantManagement restaurantManagement;
    @FXML
    private SocketWrapper socketWrapper;



    public void showTable(List<Restaurant> res){
        showCat.setVisible(false);
        tableRestaurant.getColumns().clear();
        idRc.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameRc.setCellValueFactory(new PropertyValueFactory<>("name"));
        categoryRc.setCellValueFactory(new PropertyValueFactory<>("cat"));
        priceRc.setCellValueFactory(new PropertyValueFactory<>("price"));
        zipRc.setCellValueFactory(new PropertyValueFactory<>("zipcode"));
        scoreRc.setCellValueFactory(new PropertyValueFactory<>("score"));

        tableRestaurant.getColumns().addAll(idRc, nameRc,scoreRc, priceRc,zipRc,categoryRc);
        ObservableList<Restaurant> data = FXCollections.observableArrayList(res);
        tableRestaurant.setItems(data);
    }
//public NewController(){
//        showTable(restaurantManagement.getRestaurant());
//}


    //

    public void getterR(RestaurantManagement restaurantManagement, SocketWrapper socketWrapper){
        this.restaurantManagement= restaurantManagement;
        this.socketWrapper=socketWrapper;
    }
    // Constructor for the controller (optional)

    // Event handler method for a button click, for example


    private void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect entry!!!");
        alert.setHeaderText("Use proper typing!!!");
        alert.showAndWait();
    }

    public void ButtonClicked(ActionEvent actionEvent) {
    //    String userName = search.getText();
        String userName = searchBy.getValue();

        try {
            if (userName.isEmpty()) {
                showAlert();
            } else {
                // Do something with userName
                if(userName.equalsIgnoreCase("Name")){
                    if(name.getText().isEmpty() )
                        showAlert();
                    else {


                        List<Restaurant> nameres = restaurantManagement.rfindbyName(name.getText());
                      //  restaurantManagement.rshowDetails(nameres);
                        showTable(nameres);

                    }
                    }



                else if(userName.equalsIgnoreCase("Category")){
                    if(category.getText().isEmpty() )
                        showAlert();
                    else {


                        List<Restaurant> catres = restaurantManagement.rfindbyCategory(category.getText());
                      //  restaurantManagement.rshowDetails(catres);
                        showTable(catres);

                    }
                }


                else   if(userName.equalsIgnoreCase("Price")){
                    if(price.getText().isEmpty() )
                        showAlert();
                    else {


                        List<Restaurant> priceres = restaurantManagement.rsearchbyPrice(price.getText());
                        //restaurantManagement.rshowDetails(priceres);
                        showTable(priceres);

                    }
                }



                else if(userName.equalsIgnoreCase("Score")){
                    if(scoreL.getText().isEmpty() || scoreH.getText().isEmpty())
                        showAlert();

                        String temp=scoreL.getText();
                        Double small = Double.parseDouble(temp);
                        temp=scoreH.getText();
                        Double big = Double.parseDouble(temp);
                        if(small>big)showAlert();
                    else{

                            List<Restaurant> scoreres = restaurantManagement.rsearchbyScore(big,small);
                           // restaurantManagement.rshowDetails(scoreres);
                            showTable(scoreres);
                        }

                }



                else   if(userName.equalsIgnoreCase("Zip Code")){
                    if(zip.getText().isEmpty() )
                        showAlert();
                    else {


                        List<Restaurant> zipres = restaurantManagement.rsearchbyZip(zip.getText());
                        //restaurantManagement.rshowDetails(zipres);
                        showTable(zipres);
                    }
                }
                else showAlert();



            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void loadRes(ActionEvent actionEvent) {
        showTable(restaurantManagement.getRestaurant());
    }

    public void allCategoryShow(ActionEvent actionEvent) throws IOException {
showCat.setVisible(true);
String s=restaurantManagement.getCategoryWiseRestaurantsAsString(restaurantManagement.displayCategoryWiseRestaurants());
showCat.setText(s);

    }
}
