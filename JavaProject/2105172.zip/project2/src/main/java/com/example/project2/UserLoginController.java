package com.example.project2;

import codes.RestaurantManagement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import newCodes.SocketWrapper;


import java.io.IOException;
import java.net.Socket;

public class UserLoginController {

    @FXML
    private Button userlogin;

    @FXML
    private TextField username;
    @FXML
    private SocketWrapper socketWrapper;
    @FXML
    void searchOption(ActionEvent event) {
        try {

            String name = username.getText();
            //String pass = password.getText();
            if(!name.isEmpty()) {
                RestaurantManagement restaurantManagement;
                // Establish a connection to the server
                socketWrapper = new SocketWrapper("127.0.0.1", 44444);
                socketWrapper.write("USER");
                socketWrapper.write(name);
                Object handle=socketWrapper.read();
                restaurantManagement=(RestaurantManagement) handle;
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("User.fxml"));
                Parent root = fxmlLoader.load();
                UserController controller=fxmlLoader.getController();
                controller.getter(restaurantManagement,socketWrapper);
                Scene scene = new Scene(root, 600, 400);
                Stage stage = new Stage();
                stage.setTitle("Search");
                stage.setScene(scene);
                stage.show();
               // function();
                // Load the FXML file for the owner scene

            }else{
                showAlert();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    void showAlert(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect entry!!!");
        alert.setHeaderText("Use proper username!!!");
        alert.showAndWait();
    }

}

