package com.example.project2;

import codes.Food;
import codes.Restaurant;
import codes.RestaurantManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import newCodes.SocketWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ForFoodSearch {
    @FXML
    private TextField category;

    @FXML
    private TableColumn<Food,String > categoryFc;

    @FXML
    private Button find;

    @FXML
    private TextField high;

    @FXML
    private TableColumn<Food, Integer> idFc;

    @FXML
    private TextField low;

    @FXML
    private TextField name;

    @FXML
    private TableColumn<Food, String> nameFc;

    @FXML
    private TableColumn<Food, Double> priceFc;

    @FXML
    private TextField search;

    @FXML
    private TableView<Food> tableFood;

    @FXML
    private TextField resName;
    @FXML
    private RestaurantManagement restaurantManagement;
    @FXML
    private SocketWrapper socketWrapper;

    @FXML
    private ComboBox<String> searchBy;



public void showTable(List<Food> fud){
    tableFood.getColumns().clear();
    idFc.setCellValueFactory(new PropertyValueFactory<>("restaurantId"));
    nameFc.setCellValueFactory(new PropertyValueFactory<>("name"));
    categoryFc.setCellValueFactory(new PropertyValueFactory<>("category"));
    priceFc.setCellValueFactory(new PropertyValueFactory<>("price"));


    tableFood.getColumns().addAll(idFc, nameFc,priceFc,categoryFc);
    ObservableList<Food> data = FXCollections.observableArrayList(fud);
    tableFood.setItems(data);
}

    public void getterF(RestaurantManagement restaurantManagement,SocketWrapper socketWrapper){
       // System.out.println("here size =");
        this.restaurantManagement= restaurantManagement;
        this.socketWrapper=socketWrapper;
    }

    private void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect entry!!!");
        alert.setHeaderText("Use proper typing!!!");
        alert.showAndWait();
    }
    public void ButtonClicked(ActionEvent actionEvent) {
        String userName = searchBy.getValue();


        try {
            if (userName.isEmpty()) {
                showAlert();
            } else {
                // Do something with userName
                if(userName.equalsIgnoreCase("Name")){
                    if(name.getText().isEmpty() )
                        showAlert();
                    else{  System.out.print("name: ");

                        List<Food> namefd = restaurantManagement.ffindbyName(name.getText());
                       // restaurantManagement.fshowDetails(namefd);
                        showTable(namefd);
                        }
                }

                else if(userName.equalsIgnoreCase("Name in a Restaurant")){
                    if(resName.getText().isEmpty() )
                        showAlert();
                    else{
                       String res= resName.getText();


                        List<Food> nameresfd = restaurantManagement.fsearchbyNameInRestaurant(name.getText(), res);
                      showTable(nameresfd);

                    }

                }


                else if(userName.equalsIgnoreCase("Category")){
                    if(category.getText().isEmpty() )
                        showAlert();
                    else{
                        System.out.print("category: ");

                        // Search by Category
                        List<Food> catfd = restaurantManagement.ffindbyCategory(category.getText());
                       // restaurantManagement.fshowDetails(catfd);
                        showTable(catfd);
                    }
                }
                else if(userName.equalsIgnoreCase("Category in a Restaurant")){
                    if(resName.getText().isEmpty() )
                        showAlert();
                    else{
                        String res= resName.getText();
                        List<Food> catfdinres = restaurantManagement.fsearchbyCategoryInRestaurant(category.getText(),res);
                        restaurantManagement.fshowDetails(catfdinres);

                    }

                }




 else   if(userName.equalsIgnoreCase("Costliest Food in a given Restaurant")){

                    if(resName.getText().isEmpty() )
                        showAlert();
                    else{
                        String res= resName.getText();

                        List<Food> costfd = restaurantManagement.costliestFoodInRestaurant(res);
                      showTable(costfd);

                    }

                }



                else   if(userName.equalsIgnoreCase("Price")){
                    if(low.getText().isEmpty() || high.getText().isEmpty())
                        showAlert();
                    String temp=low.getText();
                    Double small = Double.parseDouble(temp);
                    temp=high.getText();
                    Double big = Double.parseDouble(temp);
                    if(small>big)showAlert();
                    else {
                        System.out.print("lower range: ");

                        System.out.print("upper range: ");

                        List<Food> pricefd = restaurantManagement.fsearchbyPrice(big, small);
                        //restaurantManagement.fshowDetails(pricefd);
                        showTable(pricefd);

                    }
                }
                else if(userName.equalsIgnoreCase("Price in a Restaurant")){
                    if(resName.getText().isEmpty() )
                        showAlert();
                    else{
                        String res= resName.getText();
                        if(low.getText().isEmpty() || high.getText().isEmpty())
                            showAlert();
                        String temp=low.getText();
                        Double small = Double.parseDouble(temp);
                        temp=high.getText();
                        Double big = Double.parseDouble(temp);
                        if(small>big)showAlert();
                        else {
                            List<Food> pricefdinres = restaurantManagement.fsearchbyPriceRangeInRestaurant(big,small, res);

                            showTable(pricefdinres);

                        }


                    }

                }



















                else showAlert();


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addingCart(ActionEvent actionEvent) throws IOException {
    Food f=tableFood.getSelectionModel().getSelectedItem();
  //  carting.add(f);

    socketWrapper.write(f);
        System.out.println("addcart");
    }

    public void loadFood(ActionEvent actionEvent) {
        showTable(restaurantManagement.getFoodarray());
    }
}
